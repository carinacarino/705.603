# Data Analytic Template Files and Assignment
* Populate all the sections in the PreliminaryDataPipeline.ipyng
* pandasprofileing.ipynb provides a demonstration of the pandas profiling library.

**Summit the link to your repository into canvas.**